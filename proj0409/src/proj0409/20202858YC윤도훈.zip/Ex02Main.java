package proj0409;

public class Ex02Main {
    public static void main(String[] args) {
        new Ex02();
    }
}
