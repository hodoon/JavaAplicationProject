package proj0409;

public class LoginExMain {
    public static void main(String[] args) {
        new LoginEx();
    }
}
