package proj0409;

public class Ex03Main {
    public static void main(String[] args) {
        new Ex03();
    }
}
