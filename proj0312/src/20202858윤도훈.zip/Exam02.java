public class Exam02 {
    public static void main(String[] args){
        int var1 = 10;
        float var2 = 10.1f;
        double var3 = 10.2;
        char var4 = '안';
        String var5 = "안드로이드";
        String var6 = "홍길동";
        String var7 = "동양미래대학교";
        int score = 100;
        double pi = 3.14;
        System.out.println(var1 + "\t" + var2 + "\t" + var3 + "\t" + var4);
        System.out.println(var5 + "\t" + var6 + "\t" + var7 + "\t" + score + "\t" + pi);
    }
}
