package exam;

public class Exam10 {
    public static void main(String args[]){
        Tiger tiger1 = new Tiger();
        Eagle Eagle1 = new Eagle();

        tiger1.move();
        Eagle1.move();
    }
}
