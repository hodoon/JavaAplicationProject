package exam;

public class Eagle extends Animal{
    String home;
    @Override
    void move() {
        System.out.println("날아서 이동");
    }
}
