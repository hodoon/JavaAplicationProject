package exam;

public class Tiger extends Animal{
    int age;
    @Override
    void move() {
        System.out.println("4족보행");
    }
}
