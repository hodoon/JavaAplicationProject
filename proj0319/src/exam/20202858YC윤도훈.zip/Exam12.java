package exam;

public class Exam12 {
    public static void main(String args[]){
        iCat cat = new iCat();
        cat.eat();

        iTiger tiger = new iTiger();
        tiger.move();
        tiger.eat();
    }
}
