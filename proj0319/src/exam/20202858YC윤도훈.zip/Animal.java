package exam;

public abstract class Animal {
    private String name;
    abstract void move();
}
