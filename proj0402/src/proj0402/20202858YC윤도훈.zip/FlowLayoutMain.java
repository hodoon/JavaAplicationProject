package proj0402;

public class FlowLayoutMain {
    public static void main(String[] args) {
        new FlowLayoutEx();
    }
}
