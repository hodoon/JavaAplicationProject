package proj0402;

public class BoderLayoutMain {
    public static void main(String[] args) {
        new BorderLayoutEx();
    }
}
