package proj0402;

public class LoginMain {
    public static void main(String[] args) {
        LoginEx login = new LoginEx();
    }
}
