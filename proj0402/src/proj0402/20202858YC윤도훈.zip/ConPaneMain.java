package proj0402;

public class ConPaneMain {
    public static void main(String[] args) {
        new ContentPaneEx();
    }
}
