package proj0402;

public class GridLayoutMain {
    public static void main(String[] args) {
        new GridLayoutEx();
    }
}
