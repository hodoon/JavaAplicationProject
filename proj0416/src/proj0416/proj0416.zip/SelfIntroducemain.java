package proj0416;

public class SelfIntroducemain {
    public static void main(String[] args) {
        new SelfIntroduce();
    }
}
