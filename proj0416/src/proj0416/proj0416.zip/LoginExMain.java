package proj0416;

public class LoginExMain {
    public static void main(String[] args) {
        new LoginEx();
    }
}
