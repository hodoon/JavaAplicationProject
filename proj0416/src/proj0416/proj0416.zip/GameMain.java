package proj0416;

public class GameMain {
    public static void main(String[] args) {
        new GameEx();
    }
}
