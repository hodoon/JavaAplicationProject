package proj0416;

public class JPanelMain {
    public static void main(String[] args) {
        new JPanelEx01();
    }
}
